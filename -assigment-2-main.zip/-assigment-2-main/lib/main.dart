import 'package:flutter/material.dart';

import 'app/assignment_app.dart';

void main() {
  runApp(const AssignmentApp());
}

