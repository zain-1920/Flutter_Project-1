import 'package:flutter/material.dart';

import '../../core/resources/app_router.dart';
import 'widgets/onboarding_item.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: OnboardingItem(
          onSkip: () => Navigator.pushReplacementNamed(
            context,
            Routes.loginRoute,
          ),
          onContinue: () => Navigator.pushReplacementNamed(
            context,
            Routes.loginRoute,
          ),
          onSignIn: () => Navigator.pushReplacementNamed(
            context,
            Routes.loginRoute,
          ),
        ),
      ),
    );
  }
}

