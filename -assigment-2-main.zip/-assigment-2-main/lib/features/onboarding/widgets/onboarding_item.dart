import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../core/resources/app_button_styles.dart';
import '../../../core/resources/app_colors.dart';
import '../../../core/resources/app_icons.dart';
import '../../../core/resources/app_text_styles.dart';

class OnboardingItem extends StatelessWidget {
  const OnboardingItem({
    super.key,
    required this.onSkip,
    required this.onContinue,
    required this.onSignIn,
  });

  final VoidCallback onSkip;
  final VoidCallback onContinue;
  final VoidCallback onSignIn;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: TextButton(
              onPressed: onSkip,
              child: Text(
                'Skip',
                style: AppTextStyles.primaryColor14RobotoMedium,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SvgPicture.asset(AppIcons.onboarding1),
                  const SizedBox(height: 24),
                  Text(
                    'Now reading books will be easier',
                    style: AppTextStyles.darkGreyColor28OpenSansBold,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Discover and read a variety of books from different genres and authors all in one app.',
                    style: AppTextStyles.greyColor16Regular,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: onContinue,
            style: AppButtonStyles.primaryButtonStyle,
            child: Text(
              'Continue',
              style: AppTextStyles.whiteColor16OpenSansBold,
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: onSignIn,
            style: AppButtonStyles.secondaryButtonStyle,
            child: Text(
              'Sign In',
              style: AppTextStyles.whiteColor16OpenSansBold.copyWith(
                color: AppColors.primaryColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

