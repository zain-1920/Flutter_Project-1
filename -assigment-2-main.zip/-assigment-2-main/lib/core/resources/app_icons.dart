class AppIcons {
  AppIcons._();

  static const String _path = 'assets/icons/';

  static const String logo = '${_path}logo.svg';
  static const String onboarding1 = '${_path}onboarding1.svg';
}

